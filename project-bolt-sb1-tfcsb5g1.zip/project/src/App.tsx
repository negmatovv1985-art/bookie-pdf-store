import { useState } from 'react';
import Header from './components/Header';
import Hero from './components/Hero';
import ProductGrid from './components/ProductGrid';

function App() {
  const [isSignInOpen, setIsSignInOpen] = useState(false);

  return (
    <div className="min-h-screen bg-white">
      <Header onSignInClick={() => setIsSignInOpen(true)} />
      <Hero />
      <ProductGrid />

      {isSignInOpen && (
        <div className="fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-lg max-w-md w-full p-8 relative">
            <button
              onClick={() => setIsSignInOpen(false)}
              className="absolute top-4 right-4 text-gray-400 hover:text-gray-600"
            >
              ✕
            </button>
            <h2 className="text-2xl font-bold mb-6">Sign In</h2>
            <input
              type="email"
              placeholder="Email address"
              className="w-full px-4 py-3 border border-gray-300 rounded mb-4 focus:outline-none focus:border-black"
            />
            <input
              type="password"
              placeholder="Password"
              className="w-full px-4 py-3 border border-gray-300 rounded mb-6 focus:outline-none focus:border-black"
            />
            <button className="w-full bg-black text-white py-3 rounded hover:bg-gray-800 transition-colors">
              Sign In
            </button>
          </div>
        </div>
      )}
    </div>
  );
}

export default App;
