import { FileText, Download } from 'lucide-react';

interface Product {
  id: number;
  title: string;
  description: string;
  price: number;
  pages: number;
}

interface ProductCardProps {
  product: Product;
  index: number;
}

function ProductCard({ product, index }: ProductCardProps) {
  return (
    <div
      className="group bg-white border border-gray-200 rounded-lg overflow-hidden hover:shadow-2xl transition-all duration-500 cursor-pointer animate-slide-up"
      style={{ animationDelay: `${index * 100}ms` }}
    >
      <div className="aspect-[4/3] bg-gradient-to-br from-gray-50 to-gray-100 flex items-center justify-center relative overflow-hidden">
        <div className="absolute inset-0 bg-black opacity-0 group-hover:opacity-5 transition-opacity duration-500" />
        <FileText className="w-16 h-16 sm:w-20 sm:h-20 text-gray-400 group-hover:scale-110 transition-transform duration-500" />
      </div>

      <div className="p-4 sm:p-6 space-y-3 sm:space-y-4">
        <div>
          <h3 className="text-lg sm:text-xl font-bold text-gray-900 group-hover:text-black transition-colors line-clamp-2">
            {product.title}
          </h3>
          <p className="text-sm sm:text-base text-gray-600 mt-2 line-clamp-2">
            {product.description}
          </p>
        </div>

        <div className="flex items-center justify-between text-sm text-gray-500">
          <span>{product.pages} pages</span>
          <span className="text-xl sm:text-2xl font-bold text-black">
            ${product.price}
          </span>
        </div>

        <button className="w-full bg-black text-white py-3 sm:py-4 rounded-lg hover:bg-gray-900 transition-all duration-300 flex items-center justify-center space-x-2 group-hover:scale-[1.02] font-medium">
          <Download className="w-4 h-4 sm:w-5 sm:h-5" />
          <span>Purchase</span>
        </button>
      </div>
    </div>
  );
}

export default ProductCard;
