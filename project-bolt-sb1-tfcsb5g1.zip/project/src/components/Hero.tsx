function Hero() {
  return (
    <section className="pt-24 sm:pt-32 pb-12 sm:pb-16 px-4 sm:px-6 lg:px-8">
      <div className="max-w-7xl mx-auto">
        <div className="text-center space-y-4 sm:space-y-6 animate-fade-in">
          <h2 className="text-4xl sm:text-6xl lg:text-7xl font-bold tracking-tight">
            Digital Knowledge,
            <br />
            Delivered Instantly
          </h2>
          <p className="text-lg sm:text-xl text-gray-600 max-w-2xl mx-auto">
            Premium PDF collections curated for modern learners
          </p>
        </div>
      </div>
    </section>
  );
}

export default Hero;
