import { FileText } from 'lucide-react';
import ProductCard from './ProductCard';

const products = [
  {
    id: 1,
    title: 'Complete Web Development Guide',
    description: 'Master modern web development from scratch',
    price: 29.99,
    pages: 250,
  },
  {
    id: 2,
    title: 'Digital Marketing Mastery',
    description: 'Essential strategies for online success',
    price: 24.99,
    pages: 180,
  },
  {
    id: 3,
    title: 'Business Growth Blueprint',
    description: 'Scale your business with proven methods',
    price: 34.99,
    pages: 320,
  },
  {
    id: 4,
    title: 'Design Principles 2024',
    description: 'Modern design thinking and practices',
    price: 19.99,
    pages: 150,
  },
  {
    id: 5,
    title: 'Financial Freedom Guide',
    description: 'Smart investing and wealth building',
    price: 27.99,
    pages: 200,
  },
  {
    id: 6,
    title: 'Productivity Mastery',
    description: 'Get more done in less time',
    price: 22.99,
    pages: 175,
  },
];

function ProductGrid() {
  return (
    <section className="py-12 sm:py-16 px-4 sm:px-6 lg:px-8">
      <div className="max-w-7xl mx-auto">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 sm:gap-6 lg:gap-8">
          {products.map((product, index) => (
            <ProductCard key={product.id} product={product} index={index} />
          ))}
        </div>
      </div>
    </section>
  );
}

export default ProductGrid;
