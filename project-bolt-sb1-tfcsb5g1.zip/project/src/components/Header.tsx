import { useState, useEffect } from 'react';

interface HeaderProps {
  onSignInClick: () => void;
}

function Header({ onSignInClick }: HeaderProps) {
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 20);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  return (
    <header
      className={`fixed top-0 left-0 right-0 z-40 transition-all duration-300 ${
        scrolled ? 'bg-white shadow-md' : 'bg-white/95'
      }`}
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16 sm:h-20">
          <div className="flex-shrink-0">
            <h1 className="text-2xl sm:text-3xl font-bold tracking-tight">
              bookie
            </h1>
          </div>

          <nav className="hidden md:flex items-center space-x-8">
            <a
              href="#about"
              className="text-sm font-medium text-gray-700 hover:text-black transition-colors"
            >
              About
            </a>
            <a
              href="#help"
              className="text-sm font-medium text-gray-700 hover:text-black transition-colors"
            >
              Help
            </a>
            <button
              onClick={onSignInClick}
              className="text-sm font-medium text-gray-700 hover:text-black transition-colors"
            >
              Sign In
            </button>
          </nav>

          <div className="flex md:hidden items-center space-x-4">
            <button
              onClick={onSignInClick}
              className="text-sm font-medium text-gray-700"
            >
              Sign In
            </button>
          </div>
        </div>
      </div>
    </header>
  );
}

export default Header;
